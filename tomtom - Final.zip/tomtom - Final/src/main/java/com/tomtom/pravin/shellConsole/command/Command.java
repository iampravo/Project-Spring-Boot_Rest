package com.tomtom.pravin.shellConsole.command;

public interface Command {

    void process(String input);

    void getHelp();

    boolean validate(String input);
}
