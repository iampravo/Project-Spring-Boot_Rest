
package com.tomtom.pravin.shellConsole.command;

public class Exit implements Command {

    String name = "EXIT";

    @Override
    public void process(String input) {
        System.exit(1);
    }

    @Override
    public void getHelp() {
        System.out.println("Exits the Shell Console");
    }

    @Override
    public boolean validate(String input) {
        return input.toUpperCase().startsWith(name);
    }
}

