package com.tomtom.pravin.shellConsole.command;

import java.text.SimpleDateFormat;


public class Date implements Command {

    String name = "DATE";

    @Override
    public void process(String input) {
        String pattern = "dd MMM yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        System.out.println(simpleDateFormat.format(new java.util.Date()));
    }

    @Override
    public void getHelp() {
        System.out.println("Print the current date on Console");
    }

    @Override
    public boolean validate(String input) {
        return input.toUpperCase().startsWith(name);
    }
}
