package com.tomtom.pravin.shellConsole.command;

public class Print implements Command {

    String name = "Print";

    @Override
    public void process(String input) {
        String value = input.replace("print", "").replace("PRINT", "").trim();
        StringBuffer stringBuffer = new StringBuffer(value);

        if (stringBuffer.length() > 0 && stringBuffer.charAt(0) == '\"' && stringBuffer.charAt(value.length() - 1) == '\"') {
            stringBuffer.deleteCharAt(0);
            stringBuffer.deleteCharAt(stringBuffer.length() - 1);
            System.out.println(stringBuffer.toString());
        } else {
            System.out.println("Please provide valid command, use HELP to get more info.");
        }
    }

    @Override
    public void getHelp() {
        System.out.println("Prints the text passed as a parameter on to standard console");
        System.out.println("Usage :                print [message]");
    }

    @Override
    public boolean validate(String input) {
        return input.toUpperCase().startsWith("PRINT ");
    }
}
