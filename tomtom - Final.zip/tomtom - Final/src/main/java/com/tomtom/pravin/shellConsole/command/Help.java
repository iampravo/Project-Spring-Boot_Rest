package com.tomtom.pravin.shellConsole.command;

import com.tomtom.pravin.shellConsole.factory.CommandFactory;

public class Help implements Command {

    String name = "HELP";

    @Override
    public void process(String input) {
        String value = input.toUpperCase().replace(name, "").trim();

        if (value.length() > 0) {
            Command command = CommandFactory.getCommand(value);
            command.getHelp();
        } else {
            CommandFactory.commandList().forEach((command,Object) -> {
                System.out.println(command);
            });
        }
    }

    @Override
    public void getHelp() {
        CommandFactory.commandList().forEach((command,Object) -> {
            System.out.println(command);
        });
    }

    @Override
    public boolean validate(String input) {
        return input.toUpperCase().startsWith(name);
    }
}
