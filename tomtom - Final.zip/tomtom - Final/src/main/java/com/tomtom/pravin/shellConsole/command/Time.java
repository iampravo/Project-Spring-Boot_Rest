package com.tomtom.pravin.shellConsole.command;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Time implements Command {

    String name = "TIME";

    @Override
    public void process(String input) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss a");
        System.out.println(sdf.format(cal.getTime()));
    }

    @Override
    public void getHelp() {
        System.out.println("Prints the current time on Console");
    }

    @Override
    public boolean validate(String input) {
        return input.toUpperCase().startsWith(name);
    }
}
