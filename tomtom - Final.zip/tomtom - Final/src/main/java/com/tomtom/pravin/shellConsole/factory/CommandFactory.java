package com.tomtom.pravin.shellConsole.factory;

import com.tomtom.pravin.shellConsole.command.*;

import java.util.HashMap;
import java.util.Map;

public class CommandFactory {

    public static Map<String, Command> commandList() {
        Map<String, Command> commands = new HashMap<>();
        commands.put("PRINT", new Print());
        commands.put("HELP", new Help());
        commands.put("TIME", new Time());
        commands.put("EXIT", new Exit());
        commands.put("DATE", new Date());

        return commands;
    }

    public static Command getCommand(String command) {

        if (commandList().containsKey(command.toUpperCase())) {
            return commandList().get(command.toUpperCase());
        } else {
            return null;
        }
    }
}
