
import com.tomtom.pravin.shellConsole.command.Command;
import com.tomtom.pravin.shellConsole.factory.CommandFactory;

import java.util.Scanner;

public class ShellConsole {

    public static void main(String[] args) {
        ShellConsole shellConsole = new ShellConsole();
        System.out.println("Welcome to Java Shell Console");
        Scanner in = new Scanner(System.in);
        boolean keepReading = true;
        while (keepReading) {
            String str = in.nextLine();
            if (shellConsole.validateInput(str)) {
                shellConsole.process(str);
            }
        }
    }

    private void process(String str) {
        String[] values = str.split(" ");
        String commandValue = values[0];
        Command command = CommandFactory.getCommand(commandValue);
        if (null != command && command.validate(str)) {
            command.process(str);
        } else {
            System.out.println("Please provide valid command, use HELP to get more info.");
        }

    }

    public boolean validateInput(String str) {
        return null != str && !str.isEmpty();
    }
}